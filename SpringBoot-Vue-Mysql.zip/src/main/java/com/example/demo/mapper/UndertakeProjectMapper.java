package com.example.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.entity.UndertakeProject;

public interface UndertakeProjectMapper extends BaseMapper<UndertakeProject> {
}
